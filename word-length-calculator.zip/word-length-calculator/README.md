# Word Length Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nalini1998/pen/qBLbpYj/20ad57ee5552e6b295ec5d27d3841aba](https://codepen.io/Nalini1998/pen/qBLbpYj/20ad57ee5552e6b295ec5d27d3841aba).

